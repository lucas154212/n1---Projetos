package N1;

public abstract class Imovel {
    private double tamanho;
    private Localizacao localizacao;

    public double getTamanho() {
        return tamanho;
    }

    public void setTamanho(double tamanho) {
        this.tamanho = tamanho;
    }

    public Localizacao getLocalizacao() {
        return localizacao;
    }

    public void setLocalizacao(Localizacao localizacao) {
        this.localizacao = localizacao;
    }

    public abstract double calcularTaxaManutencao();
}
