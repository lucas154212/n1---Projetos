package N1;

public class Teste {

	public static void main(String[] args) {
		Casa c1 = new Casa();
		c1.setTamanho(100);
		c1.setNumeroDeQuartos(3);
		System.out.println("Taxa da casa: " + c1.calcularTaxaManutencao());
		Apartamento a1 = new Apartamento();
		a1.setAndar(5);
		a1.setTamanho(70);
		System.out.println("Taxa do apartamento: " + c1.calcularTaxaManutencao());
	}

}
