package N1;

public interface Manutencao {
	public double calcularTaxaManutencao();
}
