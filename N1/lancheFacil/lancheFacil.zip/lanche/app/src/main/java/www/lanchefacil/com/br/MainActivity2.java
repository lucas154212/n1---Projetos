package www.lanchefacil.com.br;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.material.textfield.TextInputLayout;

public class MainActivity2 extends AppCompatActivity {

    Button btnEnv;
    TextInputLayout textInputNome;
    RadioButton rb1;
    RadioButton rb2;
    RadioButton rb3;
    RadioButton rb4;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main2);

        btnEnv = findViewById(R.id.btnEnv);
        textInputNome = findViewById(R.id.textInputNome);
        rb1 = findViewById(R.id.rb1);
        rb2 = findViewById(R.id.rb2);
        rb3 = findViewById(R.id.rb3);
        rb4 = findViewById(R.id.rb4);

        btnEnv.setOnClickListener(view ->{
            Intent intent = new Intent(this, MainActivity3.class);
            String nome = textInputNome.getEditText().getText().toString();
            String opcao = "";

            if (rb1.isChecked()) opcao = "X Tudo";
            if (rb2.isChecked()) opcao = "X Salada";
            if (rb3.isChecked()) opcao = "Cheese Burger";
            if (rb4.isChecked()) opcao = "Bacon Burger";


            intent.putExtra("nome", nome);
            intent.putExtra("opcao", opcao);
            startActivity(intent);
        });

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    public void Enviar(View view ){
        radioGroup();
    }

    public void radioGroup(){
        String  opcao = "";
        if(rb1.isChecked()){
            opcao = "X tudo";
        }if(rb2.isChecked()){
            opcao = "X salada";
        }if(rb3.isChecked()){
            opcao= "Cheese Burger";
        }if(rb4.isChecked()){
            opcao = "Bacon Burger";
        }
    }
}