package com.example.salario;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    private EditText editTextS;
    private RadioGroup radioGroup;
    private RadioButton rb1;
    private RadioButton rb2;
    private RadioButton rb3;
    private Button btnNovoS;
    private TextView textNovoS;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        editTextS = findViewById(R.id.editTextS);
        radioGroup = findViewById(R.id.radioGroup);
        rb1 = findViewById(R.id.rb1);
        rb2 = findViewById(R.id.rb2);
        rb3 = findViewById(R.id.rb3);
        btnNovoS = findViewById(R.id.btnNovoS);
        textNovoS = findViewById(R.id.textNovoS);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    public void enviar(View view){
        radioGrouupp();
    }

    public void radioGrouupp(){
        double salario = Double.parseDouble(editTextS.getText().toString());
        double novoS = 0;
        if(rb1.isChecked()){
            novoS = salario * 1.40;
        } else if (rb2.isChecked()){
            novoS = salario * 1.45;
        } else if(rb3.isChecked()){
            novoS = salario * 1.50;
        }
        btnNovoS.setText(String.valueOf("R$"+novoS));
    }
}