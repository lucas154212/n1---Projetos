package www.temdetudo.com.br;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.material.textfield.TextInputLayout;

public class MainActivity3 extends AppCompatActivity {
    TextView textNome;
    Button btnVoltar;

    TextInputLayout textInputNome;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main3);
        textNome = findViewById(R.id.textNome);
        btnVoltar = findViewById(R.id.btnVoltar);
        textInputNome = findViewById(R.id.textInputNome);

        Bundle bundle = getIntent().getExtras();
        if(bundle != null){
            String nome = bundle.getString("nome");
            String resultado = "Bem vindo " + nome;
            textNome.setText(resultado);
        }

        btnVoltar.setOnClickListener(view ->{
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
        });
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
}