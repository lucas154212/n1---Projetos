package www.pizzariacom;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity3 extends AppCompatActivity {
    Button btnVoltar;
    TextView textResultado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main3);

        btnVoltar = findViewById(R.id.btnVoltar);
        textResultado = findViewById(R.id.textResultado);

        Bundle bundle = getIntent().getExtras();
        if (bundle != null) {
            String tipo = bundle.getString("tipoPizza", "Não informado");
            String forma = bundle.getString("tipoCartao", "Não informado");
            String tam = bundle.getString("tam", "Não informado");
            Double resulFinal = bundle.getDouble("resulFinal", 0.0);

            String resultado = "Tipo de Pagamento: " + forma + "\n" +
                    "Sabor da pizza: " + tipo + "\n" +
                    "Tamanho da pizza: " + tam + "\n" +
                    "Valor Final: R$ " + resulFinal;

            textResultado.setText(resultado);
        }

        btnVoltar.setOnClickListener(view -> {
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
        });

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
}
