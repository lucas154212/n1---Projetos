package www.pizzariacom;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.RadioButton;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity2 extends AppCompatActivity {
    Button btnEnviar1;
    RadioButton rb11, rb12, rb13, rb14, rb15;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main2);

        btnEnviar1 = findViewById(R.id.btnEnviar1);
        rb11 = findViewById(R.id.rb11);
        rb12 = findViewById(R.id.rb12);
        rb13 = findViewById(R.id.rb13);
        rb14 = findViewById(R.id.rb14);
        rb15 = findViewById(R.id.rb15);

        btnEnviar1.setOnClickListener(view -> {
            Intent intent = new Intent(this, MainActivity3.class);
            Bundle bundle = getIntent().getExtras();

            if (bundle != null) {
                double valor = bundle.getDouble("valor");
                String tipoPizza = bundle.getString("tipoPizza", "");
                double resulFinal = valor;
                String tam = "";

                if (rb11.isChecked()) {
                    resulFinal += 2;
                    tam = "Pequena";
                } else if (rb12.isChecked()) {
                    resulFinal += 4;
                    tam = "Média";
                } else if (rb13.isChecked()) {
                    resulFinal += 6;
                    tam = "Grande";
                }

                String tipoCartao = "";
                if (rb14.isChecked()) {
                    tipoCartao = "Cartão";
                } else if (rb15.isChecked()) {
                    tipoCartao = "Pix";
                }

                intent.putExtra("resulFinal", resulFinal);
                intent.putExtra("tam", tam);
                intent.putExtra("tipoCartao", tipoCartao);
                intent.putExtra("tipoPizza", tipoPizza);

                startActivity(intent);
            }
        });

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
}
