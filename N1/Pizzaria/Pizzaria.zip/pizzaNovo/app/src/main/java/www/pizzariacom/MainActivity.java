package www.pizzariacom;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    Button btnEnviar;
    CheckBox cb1;
    CheckBox cb2;
    CheckBox cb3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        btnEnviar = findViewById(R.id.btnEnviar);
        cb1 = findViewById(R.id.cb1);
        cb2 = findViewById(R.id.cb2);
        cb3 = findViewById(R.id.cb3);

        btnEnviar.setOnClickListener(view ->{
            Intent intent = new Intent(this, MainActivity2.class);
            Double valor = 0.0;
            String tipoPizza = "";
            if (cb1.isChecked()){
                valor += 25;
                tipoPizza = "Portuguesa";
            }if (cb2.isChecked()){
                valor += 22;
                tipoPizza = "Calabresa";
            }if(cb3.isChecked()){
                valor += 20;
                tipoPizza = "Marguerita";
            }
            intent.putExtra("tipoPizza", tipoPizza);
            intent.putExtra("valor", valor);

            startActivity(intent);
        });

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
}